<?php
 @session_start();
if(!isset($_SESSION['userName'])) 
{
header('location:login.php');
}
require_once('functions.php');
require_once('connection.php');
$user=new User(); 
 if(isset($_POST['SUBMIT'])){
       echo $fname=$_POST['fname'];
		 $lname=$_POST['lname'];
		 $uname=$_POST['uname'];
		
		
		 echo  $pwd1=md5($_POST['pwd']);
		
		 echo $password = hash('sha1', $pwd1);
		 
		
		 
		 
		echo $pwd=$pwd1.$salt;
		// echo $mpwd=base64_decode($pwd1);
		 $cpwd=$_POST['cpwd'];
		 $email=$_POST['email'];
		 $role=$_POST['role'];
		
	
       $query="INSERT INTO wp_manage_user  VALUES ('','$uname','$fname','$lname','$password','$role','$email')";  
	   echo $query;	
       $query1=mysql_query($query) or die(mysql_error);
     
          if($query1)
	{
	$to = $email; 
        $subject = "Your Login Details"; 
        $from = "pyn.srinivas0101@gmail.com";
        $message ="UserName:".$uname."   Password:".$_POST['pwd']; 
        $headers = "From: $from"; 
        $sent = mail($to, $subject, $message, $headers) ; 
         if($sent) 
         {print "Your mail was sent successfully";
         header('location:user.php'); }
         
        else 
          {print "We encountered an error sending your mail"; }
	
		
        }
    else{
	echo "<script> alert('hello')</script> ";
     }
 }
?>
	