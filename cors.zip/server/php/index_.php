<?php
echo $_GET['fileupload'];
