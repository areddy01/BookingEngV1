<?php
@session_start();
if(!isset($_SESSION['userName'])) 
{
header('location:login.php');
}
require_once('functions.php');
require_once('connection.php');
$user=new User(); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>fitow</title>
<link href="css/login.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<script type="text/javascript" src="http://ajax.googleapis.com/
ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript" src="js/properties.js">
</script>



</head>
<body>
<div  id="new">
 NEW USER
</div>
<!-- Form Code Start -->

<div  class="form">
<form id="signupForm"  method='post'  name='form' action="wp_userinsert.php" onsubmit="return validate(this);">
<p class="contact"><label for="name">FirstName:</label></p>
    <input type='text' name='fname' id='fname' required=" " maxlength="50"  />
    <p class="contact"><label for="name">LastName:</label></p>
    <input type='text' name='lname' id='lname' required=" " maxlength="50"  />
    <p class="contact"><label for="name">UserName:</label></p>
    <input type='text' name='uname' id='uname' required=" " maxlength="50"  />
    <p class="contact"><label for="name">Password:</label></p>
    <input type='text' name='pwd' id='pwd' required=" " maxlength="50"  />
    <p class="contact"><label for="name">ConformPassword:</label></p>
    <input type='text' name='cpwd' id='cpwd' required=" " maxlength="50"  />
    <p class="contact"><label for="name">Role:</label></p>
    <!--<input type='text' name='role' id='name' required=" " maxlength="50"  />-->
    <select name='role' id='name' required=" ">
     <option>Super Admin</option>
    <option>User</option></select>
    <p class="contact"><label for="name">Email:</label></p>
    <input type='text' name='email' id='email' required=" " maxlength="50"  />
     <p class="contact"><label for="name"><input class="button" type="submit"  name="SUBMIT" value="SUBMIT"  />
     </label></p></form>
</div>


</body>
</html>